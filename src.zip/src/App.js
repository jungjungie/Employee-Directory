import React, { useState } from 'react';
import Header from './components/Header/Header';
import SearchBar from './components/SearchBar/SearchBar';
import EmployeeTable from './components/EmployeeTable/EmployeeTable';
import TableRows from "./components/TableRows/TableRows";
import tempData from "../src/temp.json";
import './index.css';

function App() {

	const [employees, setEmployees] = useState(tempData);
	console.log(employees);

	const filterSearch = str => {

		let newEmployeeList = employees.filter(item => item.includes(str));

		setEmployees(newEmployeeList);
	}

	// setEmployees(employees);

	return (
		<>
			<Header />
			<SearchBar />
			<EmployeeTable>
				{employees.map(employee => 
				<TableRows
					key={employee.id}
					image={employee.image}
					name={employee.name}
					phone={employee.phone}
					email={employee.email}
					DOB={employee.DOB} 
					filterSearch={filterSearch}
				/>)}
			</EmployeeTable>
		</>
	);
}

export default App;
